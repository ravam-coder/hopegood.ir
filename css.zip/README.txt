For more tutorials just copy the link below and visit:

http://www.karbarwp.com/

Hope will help you this simple work.
Thank you.
google-site-verification=dsmbggbbnVy8Utk624KMkhuzH9F7boqVlxxuMVN-NX4